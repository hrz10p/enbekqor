import React, { useState, useEffect } from "react";
import {View, StyleSheet, Text, TouchableOpacity, ScrollView} from "react-native";
import { useTranslation } from "react-i18next";
import DropDownPicker from "react-native-dropdown-picker";
import i18n from "@/utilities/internationalization"
import {Image} from "expo-image";
import LanguagePicker from "@/components/LanguagePicker";

export default function ProfileScreen() {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(i18n.language);
  const [items, setItems] = useState([
    { label: t("russian"), value: "ru" },
    { label: t("kazakh"), value: "kz" },
  ]);

  // useEffect(() => {
  //   setItems([
  //     { label: t("russian"), value: "ru" },
  //     { label: t("kazakh"), value: "kz" },
  //   ]);
  // }, [i18n.language]);

    const mock = [
        {
            id: 1,
            title: "Жалоба 1",
            description: "Жалоба 1 была подана потому что..."
        },
        {
            id: 2,
            title: "Жалоба 2",
            description: "Жалоба 2 была подана потому что..."
        },
        {
            id: 3,
            title: "Жалоба 3",
            description: "Жалоба 3 была подана потому что..."
        },
        {
            id: 4,
            title: "Жалоба 4",
            description: "Жалоба 4 была подана потому что..."
        }
    ]

  return (
      <ScrollView style={styles.container}>
          <View style={styles.userShortInfo}>
              <View style={styles.userAvatarBlock}>
                  <Image
                      source={require("../../assets/images/icons/avatar-15.png")}
                      style={[styles.userAvatarImage]}
                      contentFit={"contain"}
                  />
              </View>
              <View style={styles.userData}>
                  <Text style={styles.userDataName}>
                      Викторов Виктор
                  </Text>
                  <Text style={styles.userDataAgeCity}>
                      20 лет, г. Астана
                  </Text>
              </View>
              <LanguagePicker></LanguagePicker>
          </View>
          <View style={styles.userApplicationsBlock}>
              <Text style={{fontSize: 25, fontWeight: "bold"}}>
                  История жалоб
              </Text>
              {mock.map((mockApp, index) => (
                  <TouchableOpacity
                    key={mockApp.id}
                    style={styles.userApplication}
                  >
                      <Text style={styles.userApplicationTitle}>
                          {mockApp.title}
                      </Text>
                      <Text style={styles.userApplicationDescription}>
                          {mockApp.description}
                      </Text>
                  </TouchableOpacity>
              ))}
          </View>

      </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
      paddingTop: 60,
      width: "100%",
      height: "100%",
      padding: 10,
  },
    userShortInfo: {
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "flex-start",
        padding: 10,
        gap: 15, // Ensures spacing between avatar and text
    },
    userAvatarBlock: {
        width: 50, // Adjusted for better fit
        height: 50,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 25,
        backgroundColor: "#E5E5E5", // Optional background
    },
    userAvatarImage: {
        width: "100%",
        height: "100%",
    },
    userInfoContainer: {
        flex: 1, // Ensures text and dropdown are aligned properly
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    userData: {
        flex: 1, // Takes available space
        paddingHorizontal: 10,
    },
    userDataName: {
        color: "#000",
        fontSize: 19,
        fontWeight: "bold",
        textAlign: "center",
    },
    userDataAgeCity: {
        color: "#000",
        fontSize: 15,
        textAlign: "center",
    },
    dropDown: {
        width: 100, // Adjust width
        marginLeft: "auto", // Pushes dropdown to the right
        zIndex: 10,
    },
    userApplicationsBlock: {
      height: "100%",
        zIndex: 1
    },
    userApplication: {
      marginVertical: 10,
        padding: 10,
        borderRadius: 15,
        shadowColor: "rgba(34, 60, 80, 1)",
        shadowOffset: {width: 0, height: 4},
        shadowRadius: 4,
        shadowOpacity: 0.2,
        // boxShadow: 4px 4px 8px 0px ;
    },
    userApplicationTitle: {
        fontSize: 17,
        fontWeight: "bold",
    },
    userApplicationDescription: {
        fontSize: 15
    }
});
