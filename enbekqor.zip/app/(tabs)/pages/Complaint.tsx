import React, { useState } from "react";
import {
    View, Text, TextInput, TouchableOpacity, StyleSheet, Alert
} from "react-native";
import * as DocumentPicker from "expo-document-picker";

export default function ComplaintScreen() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [complaint, setComplaint] = useState("");
    const [attachedFile, setAttachedFile] = useState<DocumentPicker.DocumentPickerAsset | null>(null);



    // Function to pick a file
    const pickDocument = async () => {
        let result = await DocumentPicker.getDocumentAsync({});
        if (!result.canceled && result.assets.length > 0) {
            setAttachedFile(result.assets[0]);
        }
    };

    const handleSubmit = () => {
        if (!name || !email || !complaint) {
            Alert.alert("Ошибка", "Пожалуйста, заполните все обязательные поля.");
            return;
        }
        Alert.alert("Успех", "Ваша жалоба отправлена.");
        setName("");
        setEmail("");
        setComplaint("");
        setAttachedFile(null);
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Подать жалобу</Text>

            <TextInput
                style={styles.input}
                placeholder="Ваше имя"
                value={name}
                onChangeText={setName}
            />

            <TextInput
                style={styles.input}
                placeholder="Ваш email"
                keyboardType="email-address"
                value={email}
                onChangeText={setEmail}
            />

            <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Опишите проблему"
                multiline
                numberOfLines={5}
                value={complaint}
                onChangeText={setComplaint}
            />

            {/* File Attachment */}
            {/*<TouchableOpacity style={styles.fileButton} onPress={pickDocument}>*/}
            {/*    <Text style={styles.fileButtonText}>*/}
            {/*        {attachedFile ? `Файл: ${attachedFile.name}` : "Прикрепить файл (необязательно)"}*/}
            {/*    </Text>*/}
            {/*</TouchableOpacity>*/}

            <TouchableOpacity style={styles.button} onPress={handleSubmit}>
                <Text style={styles.buttonText}>Отправить</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        paddingTop: 60,
        flex: 1,
        backgroundColor: "#f4f9ff",
        padding: 20,
        justifyContent: "center",
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#2A66FF",
        textAlign: "center",
        marginBottom: 20,
    },
    input: {
        backgroundColor: "#fff",
        padding: 12,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: "#A5C0FF",
        marginBottom: 15,
    },
    textArea: {
        height: 100,
        textAlignVertical: "top",
    },
    fileButton: {
        backgroundColor: "#E0EBFF",
        padding: 12,
        borderRadius: 8,
        alignItems: "center",
        marginBottom: 15,
    },
    fileButtonText: {
        color: "#2A66FF",
        fontSize: 16,
    },
    button: {
        backgroundColor: "#2A66FF",
        padding: 14,
        borderRadius: 8,
        alignItems: "center",
    },
    buttonText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: 16,
    },
});
