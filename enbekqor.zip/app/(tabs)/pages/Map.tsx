import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";

const mockBranches = [
    {
        id: 1,
        name: "Главный офис",
        address: "ул. Абая, 10, г. Астана",
        contact: "+7 (7172) 123-456",
    },
    {
        id: 2,
        name: "Филиал в Алматы",
        address: "пр. Аль-Фараби, 50, г. Алматы",
        contact: "+7 (727) 654-321",
    },
    {
        id: 3,
        name: "Филиал в Караганде",
        address: "ул. Бейбітшілік, 25, г. Караганда",
        contact: "+7 (7212) 789-123",
    }
];

export default function BranchesMapPage() {
    return (
        <View style={styles.container}>
            {/* Placeholder for the Map */}
            <View style={styles.mapPlaceholder}>
                <Text style={styles.mapText}>Карта (будет добавлена позже)</Text>
            </View>

            {/* List of Branches */}
            <ScrollView style={styles.branchesList}>
                {mockBranches.map(branch => (
                    <View key={branch.id} style={styles.branchCard}>
                        <Text style={styles.branchName}>{branch.name}</Text>
                        <Text style={styles.branchDetails}>{branch.address}</Text>
                        <Text style={styles.branchDetails}>{branch.contact}</Text>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#F0F4F8",
        padding: 10,
        paddingTop: 60,
    },
    mapPlaceholder: {
        height: 250,
        backgroundColor: "#D0E0F0",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 10,
        marginBottom: 20
    },
    mapText: {
        fontSize: 16,
        color: "#555"
    },
    branchesList: {
        flex: 1
    },
    branchCard: {
        backgroundColor: "#FFFFFF",
        padding: 15,
        borderRadius: 10,
        marginBottom: 10,
        shadowColor: "#000",
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 4,
        elevation: 3
    },
    branchName: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#333"
    },
    branchDetails: {
        fontSize: 16,
        color: "#555",
        marginTop: 5
    },
    branchCoordinates: {
        fontSize: 14,
        color: "#777",
        marginTop: 5,
        fontStyle: "italic"
    }
});