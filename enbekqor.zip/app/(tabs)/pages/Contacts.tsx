import React from "react";
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";

// Mock Data
const contacts = [
    { id: "1", name: "Служба поддержки", phone: "+7 777 123 4567", email: "support@example.com" },
    { id: "2", name: "Юридический отдел", phone: "+7 727 555 6789", email: "legal@example.com" },
    { id: "3", name: "Финансовый отдел", phone: "+7 701 987 6543", email: "finance@example.com" },
];

export default function ContactsScreen() {
    return (
        <View style={styles.container}>
            <Text style={styles.header}>Контакты</Text>
            <FlatList
                data={contacts}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <View style={styles.contactCard}>
                        <View style={styles.contactInfo}>
                            <Text style={styles.contactName}>{item.name}</Text>
                            <Text style={styles.contactText}>
                                <Ionicons name="call-outline" size={16} color="#599BFF" /> {item.phone}
                            </Text>
                            <Text style={styles.contactText}>
                                <MaterialIcons name="email" size={16} color="#599BFF" /> {item.email}
                            </Text>
                        </View>
                        <TouchableOpacity style={styles.callButton}>
                            <Ionicons name="call" size={24} color="#fff" />
                        </TouchableOpacity>
                    </View>
                )}
            />
        </View>
    );
}

// Styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#F7F9FC",
        paddingHorizontal: 20,
        paddingTop: 60,
    },
    header: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#333",
        marginBottom: 20,
    },
    contactCard: {
        backgroundColor: "#fff",
        padding: 15,
        borderRadius: 12,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 12,
        shadowColor: "#000",
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 4,
        elevation: 2, // Android shadow
    },
    contactInfo: {
        flex: 1,
    },
    contactName: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#333",
        marginBottom: 5,
    },
    contactText: {
        fontSize: 14,
        color: "#555",
        marginBottom: 3,
    },
    callButton: {
        backgroundColor: "#599BFF",
        width: 50,
        height: 50,
        borderRadius: 25,
        justifyContent: "center",
        alignItems: "center",
    },
});
