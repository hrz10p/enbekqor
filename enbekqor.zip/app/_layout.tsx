import { Stack } from "expo-router";
import { LanguageProvider } from "./LanguageContext";

export default function RootLayout() {
    return (
        <LanguageProvider>
            <Stack>
                <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                <Stack.Screen name="+not-found" />
            </Stack>
        </LanguageProvider>
    );
}
